#!/usr/bin/env bash
set -e
cd /app/repo || true
echo "进入目录: $(pwd)"
ls -la

if [ -f demo.py ]; then
  python demo.py
  exit 0
fi

echo "lottokit 可能為庫形式，請參考 README-zh.md 以了解如何在容器內手動運行演示腳本。"
sleep infinity
