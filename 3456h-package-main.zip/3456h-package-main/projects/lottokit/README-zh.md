# lottokit（演示封装）

原項目：
https://github.com/nickdecodes/lottokit

說明：
lottokit 是一個工具包/庫，本容器會拉取源码。若要使用库内部功能，请进入容器并按 README 使用 Python 调用库函数。
