#!/usr/bin/env bash
set -e
cd /app/repo || true
echo "进入目录: $(pwd)"
ls -la

if command -v streamlit >/dev/null 2>&1 && [ -f app.py ]; then
  streamlit run app.py --server.port=8501 --server.address=0.0.0.0
  exit 0
fi

if [ -f notebook.ipynb ]; then
  pip install jupyter || true
  jupyter notebook --ip=0.0.0.0 --no-browser --allow-root --NotebookApp.token=''
  exit 0
fi

echo "未检测到自动入口，请参考 projects/LotteryPredict/README-zh.md 或原仓庫 README。"
sleep infinity
