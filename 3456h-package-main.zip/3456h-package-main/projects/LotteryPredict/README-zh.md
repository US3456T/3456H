# LotteryPredict（演示封装）

原項目：
https://github.com/melvincabatuan/LotteryPredict

說明：
演示使用 LSTM 的示例。構建後如未自動運行，請參考原倉庫的 Notebook 或 README。
