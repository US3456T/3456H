#!/usr/bin/env bash
set -e
cd /app/repo || true
echo "进入目录: $(pwd)"
ls -la

if command -v streamlit >/dev/null 2>&1 && [ -f app.py ]; then
  streamlit run app.py --server.port=8501 --server.address=0.0.0.0
  exit 0
fi

if [ -f main.py ]; then
  python main.py
  exit 0
fi

echo "未检测到自动入口，请参考 projects/LotteryAi/README-zh.md 或原仓库 README。"
sleep infinity
