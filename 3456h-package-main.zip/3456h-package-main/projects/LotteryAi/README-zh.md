# LotteryAi（演示封装）

原項目：
https://github.com/CorvusCodex/LotteryAi

說明：
此目錄在構建時會拉取原項目代碼並嘗試運行。若運行出錯，請查看原倉庫的 README 並按其依賴安裝方法調整 Dockerfile。
