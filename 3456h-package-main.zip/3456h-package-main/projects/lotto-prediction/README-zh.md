# Lotto-prediction（演示封装）

原项目：
https://github.com/michaelkupfer97/Lotto-prediction

说明：
构建时会克隆原项目并尝试按常见入口运行（Streamlit / demo.py / app.py / notebook）。
若启动失败，请进入容器或本地查看原项目 README 以获得运行指令。
