#!/usr/bin/env bash
set -e
cd /app/repo || true
echo "进入目录: $(pwd)"
ls -la

# 尝试启动 Streamlit
if command -v streamlit >/dev/null 2>&1 && [ -f app.py ]; then
  streamlit run app.py --server.port=8501 --server.address=0.0.0.0
  exit 0
fi

# 其它常见入口
if [ -f demo.py ]; then
  python demo.py
  exit 0
fi
if [ -f app.py ]; then
  python app.py
  exit 0
fi

if command -v jupyter >/dev/null 2>&1 && ls *.ipynb 1>/dev/null 2>&1; then
  jupyter notebook --ip=0.0.0.0 --no-browser --allow-root --NotebookApp.token=''
  exit 0
fi

echo "未检测到自动可运行入口，请查看 projects/lotto-prediction/README-zh.md 按照原项目 README 手动运行。"
sleep infinity
